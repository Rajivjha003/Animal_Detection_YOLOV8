# Animal Detection > 2024-03-18 12:45pm
https://universe.roboflow.com/objectdetection-aqiuz/animal-detection-o3k3w

Provided by a Roboflow user
License: CC BY 4.0

